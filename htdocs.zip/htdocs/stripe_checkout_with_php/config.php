<?php 
 
// Product Details  
// Minimum amount is $0.50 US  
$productName = "DISCORD NITRO";  
$productID = "12345";  
$productPrice = 4; 
$currency = "BRL"; 
  
/* 
 * Stripe API configuration 
 * Remember to switch to your live publishable and secret key in production! 
 * See your keys here: https://dashboard.stripe.com/account/apikeys 
 */ 
define('STRIPE_SECRET_KEY', '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'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51Pe6032LQY1lcDyRdjTZABKKw7UaCvC3iPmy89Oud7FqSxYTHD9gk88H8t3jyrAiW68PYkpNMI7oGMxJpcs1BQIo009jC4LLMG'); 
define('STRIPE_SUCCESS_URL', 'https://localhost/stripe_checkout_with_php/payment-success.php'); //Payment success URL 
define('STRIPE_CANCEL_URL', 'https://localhost/stripe_checkout_with_php/payment-cancel.php'); //Payment cancel URL 
    
// Database configuration    
define('DB_HOST', 'localhost');   
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', 'root');   
define('DB_NAME', 'transactions.sql'); 
 
?>