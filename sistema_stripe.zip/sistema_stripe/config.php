<?php 

$productName = "DISCORD NITRO";  
$productID = "12345";  
$productPrice = 4; 
$currency = "BRL"; 
  

define('STRIPE_SECRET_KEY', 'sk_live_51'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51'); 
define('STRIPE_SUCCESS_URL', 'https://localhost/stripe_checkout_with_php/payment-success.php');  
define('STRIPE_CANCEL_URL', 'https://localhost/stripe_checkout_with_php/payment-cancel.php'); 
    
// Database configuration    
define('DB_HOST', 'localhost');   
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', 'root');   
define('DB_NAME', 'transactions.sql'); 
 
?>